# vehicle-number-plate-detection
This Project is self made project projecting the use of machine learning techniques to Recog. Indian license plate numbers 
The dataset is self-made to make the project more realistic and to test if it work using less training data set

I have also used web scrapping to get the deatils of the Indian License plate of the particular vehicle from  webpage of (mparivahaan)
#cracked the Captcha using the same technique used to recognise the Licence plate 

data set have large number of image URL
In code I have place a loop to only run 10 data set if you want you can change the limit to perform test on all data set
